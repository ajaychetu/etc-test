
/*
 http.createServer(async function (request, response) {

    const csvFilePath='C2ImportFamRelSample.csv';

    // Async / await usage
    const jsonArray=await csv().fromFile(csvFilePath);
    // Send the HTTP header 
    // HTTP Status: 200 : OK
    // Content Type: text/plain
    response.writeHead(200, {'Content-Type': 'text/plain'});
    
    // Send the response body as "Hello World"
    //response.end('Hello World\n');
    
    response.sendFile('/Homepage.html');

    console.log(jsonArray);
 }).listen(8081);

/*
 async function fun1(req, res){
    let response = await request.get('http://localhost:3000');
      if (response.err) { console.log('error');}
      else { console.log('fetched response');
  }*/
 
 // Console will print the message*/

let http = require('http');
let router = require('./routes');
const csv=require('csvtojson');

let handleRequest = (request, response) => {
    response.writeHead(200, {
        'Content-Type': 'text/html'
    });
 
};
 
http.createServer(router.handleRequest).listen(8081);
 console.log('Server running at http://127.0.0.1:8081/');