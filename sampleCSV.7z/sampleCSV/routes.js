const url = require('url');
let fs = require('fs');
const csv=require('csvtojson');
 
html = {
    render(path, response) {
        fs.readFile(path, null, function (error, data) {
            if (error) {
                response.writeHead(404);
                respone.write('file not found');
            } else {
                console.log(data);
                response.write(data);
            }
            response.end();
        });
    }
}
 
module.exports = {
    handleRequest(request, response) {
        response.writeHead(200, {
            'Content-Type': 'text/html'
        });
 
        let path = url.parse(request.url).pathname;
    console.log( 'tetsing..' + path);
         
        switch (path) {
            case '/':
                html.render('./index.html', response);
                break;
            case '/about':
                html.render('./about.html', response);
                break;
            case '/homepage':
                html.render('./homepage.html', response);
                break;    
            case '/upload':
                html.render('./upload.html', response);
                break;
            case '/parsed':
               // html.render('./about.html', response);
                //let data = fun1();
               // console.log(data);
               // Promise.resolve(data).then(JSON.parse).then(
                    
                     // );
                  const csvFilePath='C2ImportFamRelSample.csv';
                   csv().fromFile(csvFilePath)
                   .then((jsonObj)=>{
                           console.log(jsonObj[0].Parent);

                           response.write(jsonObj[0].Parent);
                            /**
                             * [
                             * 	{a:"1", b:"2", c:"3"},
                             * 	{a:"4", b:"5". c:"6"}
                             * ]
                             */ 
                         // var data =  JSON.parse(jsonObj);

                          //console.log(data);
                    })
                   
                response.write('Completed...');
                response.end();
                break;
            
            default:
                response.writeHead(404);
                response.write('Route not found');
                response.end();
        }
    }
}

async function fun1(){
    const csvFilePath='C2ImportFamRelSample.csv';
    let jsonArray=await csv().fromFile(csvFilePath);
    return jsonArray; 
}